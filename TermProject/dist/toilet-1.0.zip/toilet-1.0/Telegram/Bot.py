import telepot
bot = telepot.Bot("5529657440:AAGR0XLgywk0b88G512odGm1yTbcpw2guAg")
print(bot.getMe())
bot.sendMessage('5468016315','hi!')